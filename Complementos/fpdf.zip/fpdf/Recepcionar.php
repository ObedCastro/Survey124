<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require('fpdf.php');
class PDF extends FPDF
{
    // Cargar la fuente personalizada
    function AddFontMuseoSans()
    {
        $fontPath = 'font/Museo Sans 300 Regular.ttf'; // Reemplaza con la ubicación de tu archivo de fuente

       $this->AddFont('Museo_Sans', '', $fontPath);
    }
   //Pie de página
   function Footer()
   {
    //Posición: a 1,5 cm del final
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Número de página
    $this->Cell(0,10,'Documento Confidencial - Pagina'.$this->PageNo().'/{nb}',0,0,'C');
   }
}
$pdf=new PDF('P','mm',array(216,279));
$pdf->SetMargins(28, 25, 28);
$pdf->AliasNbPages();
//Primera página
$pdf->AddPage();
//$pdf->AddFontMuseoSans();
$pdf->SetFont('Arial','B',13);
$pdf->Image('img/MARCA DE WATER.png',0, 0, 216);
$pdf->Image('img/logo_BCR.png',85,15,38);
$pdf->Ln(15);
$pdf->SetFont('Arial','B',13);
$pdf->Cell(0,10,mb_convert_encoding('RECEPCIÓN DE DISPOSITIVO MÓVIL', 'ISO-8859-1', 'UTF-8'),0,0,'C');
$pdf->Ln(15);
$pdf->SetFont('Arial','',11);
$pdf->MultiCell(0, 5, mb_convert_encoding('En este acto se hace recepcion de: NATALY MARIA VAQUERANO GRANILLO, con el cargo de: CARTOGRAFO destacado en la sede: EXBANDESAL SAN MIGUEL el dispositivo que a continuación se describe:','ISO-8859-1', 'UTF-8'), 0, 1);
$pdf->Ln(8);
//TABLA CABEX
$pdf->SetFont('Arial','B',11);
//Cabecera
$pdf->setTextColor(255, 255, 255);
$pdf->SetFillColor(29,80,153);
$pdf->SetLineWidth(.3);
$pdf->SetFont('','B');
$pdf->Cell(30,6,'DESCRIPCION',1,0,'C',1);
$pdf->Cell(30,6,'MARCA',1,0,'C',1);
$pdf->Cell(36,6,'MODELO',1,0,'C',1);
$pdf->Cell(36,6,'IMEI',1,0,'C',1);
$pdf->Cell(25,6,'TELEFONO',1,0,'C',1);
$pdf->Ln();
//Datos
$pdf->SetFillColor(224,235,255);
$pdf->SetTextColor(0);
$pdf->SetFont('');
$pdf->Cell(30,6,"MOVIL",'LR',0,'C');
$pdf->Cell(30,6,"SAMSUNG",'LR',0,'C');
$pdf->Cell(36,6,"GALAXY A34",'LR',0,'C');
$pdf->Cell(36,6,"351326801779574",'LR',0,'C');
$pdf->Cell(25,6,"72877196",'LR',0,'C');
$pdf->Ln();
$pdf->Cell(157,0,'','T');


$pdf->Ln(10);
$pdf->SetFont('Arial','',11);
$pdf->Cell(0,5,'Con los siguientes accesorios:',0,0,'C');
$pdf->Ln(10);
$pdf->Cell(0,5,mb_convert_encoding(' *  Cubo de carga','ISO-8859-1', 'UTF-8'),0,1);
$pdf->Rect(73, 110, 8, 4, 'D');
$pdf->Cell(0,5,mb_convert_encoding(' *  Cable USB tipo C','ISO-8859-1', 'UTF-8'),0,1);
$pdf->Rect(73, 115, 8, 4, 'D');
$pdf->Cell(0,5,mb_convert_encoding(' *  Funda del Dispositivo','ISO-8859-1', 'UTF-8'),0,1);
$pdf->Rect(73, 120, 8, 4, 'D');
$pdf->Cell(0,5,mb_convert_encoding(' *  Lapiz','ISO-8859-1', 'UTF-8'),0,1);
$pdf->Rect(73, 125, 8, 4, 'D');

$pdf->Ln(8);
$pdf->SetFont('Arial','',11);
$pdf->Cell(0,5,'Comentarios:',0,0,'L');
$pdf->Rect(28, 143, 158, 50, 'D');
$pdf->Ln(55);
$pdf->SetFont('Arial','',11);
$pdf->Cell(0,20,'Entrega:',0,0,'L',0);
$pdf->Cell(0,20,'Recibe:                                       ',0,0,'R',0);
$pdf->Ln();
$pdf->Cell(0,8,'F:________________________',0,0,'L',0);
$pdf->Cell(0,8,'F:________________________',0,0,'R',0);
$pdf->Ln();
$pdf->SetFont('Arial','',11);
$pdf->Cell(0,5,mb_convert_encoding('Nombre: Miguel Portillo','ISO-8859-1', 'UTF-8'),0,0,'L',0);
$pdf->Cell(0,5,mb_convert_encoding('Nombre: Miguel Angel Portillo Lozano','ISO-8859-1', 'UTF-8'),0,0,'R',0);
$pdf->Ln();
$pdf->Cell(0,5,mb_convert_encoding('Cargo: Técnico de Soporte Informático','ISO-8859-1', 'UTF-8'),0,0,'L',0);
$pdf->Cell(0,5,mb_convert_encoding('Cargo: Técnico de Soporte Informático','ISO-8859-1', 'UTF-8'),0,0,'R',0);
$pdf->Ln(10);
$pdf->SetFont('Arial','U',11);
$pdf->Cell(0,5,mb_convert_encoding('San Miguel, 27 de noviembre 2023','ISO-8859-1', 'UTF-8'),0,1,'R');
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,5,mb_convert_encoding('Lugar                             Fecha                   ','ISO-8859-1', 'UTF-8'),0,1,'R');

$pdf->Ln(10);
$pdf->SetFont('Arial','',10);
$pdf->Output('', 'Hoja de Recepcion de Dispositivo.pdf');
?>