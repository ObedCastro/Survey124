<?php

require "../modelos/conexion.php";
require_once "../controladores/dispositivos.controlador.php";
require_once "../controladores/consultores.controlador.php";
require_once "../modelos/dispositivos.modelo.php";
require_once "../modelos/consultores.modelo.php";

require('fpdf.php');
class PDF extends FPDF
{
    
   //Pie de página
   function Footer()
   {
    //Posición: a 1,5 cm del final
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Número de página
    $this->Cell(0,10,'Documento Confidencial - Pagina'.$this->PageNo().'/{nb}',0,0,'C');
   }
}


if(isset($_GET["idDispositivoAsignar"]) && isset($_GET["responsableDispositivo"])){
    $id = $_GET["idDispositivoAsignar"];
    $res = $_GET["responsableDispositivo"];

    $datos = array(
        "Cubo"=>isset($_GET["checkCubo"]) == "on" ? "1" : "0",
        "Cable"=>isset($_GET["checkCable"]) == "on" ? "1" : "0",
        "Funda"=>isset($_GET["checkFunda"]) == "on" ? "1" : "0",
        "Lapiz"=>isset($_GET["checkLapiz"]) == "on" ? "1" : "0",
        "Powerbank"=>isset($_GET["checkPowerbank"]) == "on" ? "1" : "0",
        "Maletin"=>isset($_GET["checkMaletin"]) == "on" ? "1" : "0",
        "Cargador"=>isset($_GET["checkCargador"]) == "on" ? "1" : "0",
        "Mouse"=>isset($_GET["checkMouse"]) == "on" ? "1" : "0",
        "Mousepad"=>isset($_GET["checkMousepad"]) == "on" ? "1" : "0"
    );

    $accesorios = json_encode($datos);

    $respuesta = ControladorDispositivos::ctrAsignarDispositivo($id, $res, $accesorios);
    $accesorios = json_decode($respuesta[0]["accesorios"]);

    $responsable = ControladorConsultores::ctrMostrarConsultores("idconsultor", $respuesta[0]["responsabledispositivo"]);

    try {

        $pdf=new PDF('P','mm',array(216,279));
        $pdf->SetMargins(28, 25, 28);
        $pdf->AliasNbPages();
        //Primera página
        $pdf->AddPage();
        //$pdf->AddFontMuseoSans();
        $pdf->SetFont('Arial','B',13);
        //$pdf->Image('img/MARCA DE WATER.png',0, 0, 216);
        //$pdf->Image('img/logo_BCR.png',85,15,38);
        $pdf->Ln(15);
        $pdf->SetFont('Arial','B',13);
        $pdf->Cell(0,10,mb_convert_encoding('ASIGNACIÓN DE DISPOSITIVO MÓVIL','ISO-8859-1', 'UTF-8'),0,0,'C');
        $pdf->Ln(15);
        $pdf->SetFont('Arial','',11);
        $pdf->MultiCell(0, 5, mb_convert_encoding('En este acto se hace entrega a: '.strtoupper($responsable["nombreconsultor"]).', con el cargo de: '.strtoupper($responsable["cargoconsultor"]).' destacado en la sede: '.strtoupper($responsable["sedeconsultor"]).' del dispositivo que a continuación se describe:', 'ISO-8859-1', 'UTF-8'), 0, 1);
        $pdf->Ln(8);
        //TABLA CABEX
        $pdf->SetFont('Arial','B',11);
        //Cabecera
        $pdf->setTextColor(255, 255, 255);
        $pdf->SetFillColor(29,80,153);
        $pdf->SetLineWidth(.3);
        $pdf->SetFont('','B');
        $pdf->Cell(30,6,'DESCRIPCION',1,0,'C',1);
        $pdf->Cell(30,6,'MARCA',1,0,'C',1);
        $pdf->Cell(36,6,'MODELO',1,0,'C',1);
        $pdf->Cell(36,6,'IMEI/SERIE',1,0,'C',1);
        $pdf->Cell(25,6,'TELEFONO',1,0,'C',1);
        $pdf->Ln();
        //Datos
        $pdf->SetFillColor(224,235,255);
        $pdf->SetTextColor(0);
        $pdf->SetFont('');

        foreach ($respuesta as $fila) {
        $pdf->Cell(30,6,$fila['tipodispositivo'],'LR',0,'C');
        $pdf->Cell(30,6,$fila['marcadispositivo'],'LR',0,'C');
        $pdf->Cell(36,6,$fila['modelodispositivo'],'LR',0,'C');
        if($fila['imeidispositivo'] != ''){
            $pdf->Cell(36,6,$fila['imeidispositivo'],'LR',0,'C');
        } else{
            $pdf->Cell(36,6,$fila['seriedispositivo'],'LR',0,'C');
        }
        $pdf->Cell(25,6,$fila['telefonodispositivo'],'LR',0,'C');
        }

        /*$pdf->Cell(30,6,"MOVIL",'LR',0,'C');
        $pdf->Cell(30,6,"SAMSUNG",'LR',0,'C');
        $pdf->Cell(36,6,"GALAXY A34",'LR',0,'C');
        $pdf->Cell(36,6,"351326801779574",'LR',0,'C');
        $pdf->Cell(25,6,"72877196",'LR',0,'C');*/
        $pdf->Ln();
        $pdf->Cell(157,0,'','T');   

        $pdf->Ln(10);
        $pdf->SetFont('Arial','',11);
        $pdf->Cell(0,5,'Con los siguientes accesorios:',0,0,'C');
        $pdf->Ln(10);

        if($respuesta[0]["tipodispositivo"] == "Telefono" || $respuesta[0]["tipodispositivo"] == "Tablet"){
            if($accesorios->Cubo == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Cubo de carga               '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 110, 8, 4, 'D');                
            }
            if($accesorios->Cable == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Cable USB tipo C          '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 115, 8, 4, 'D');
            }
            if($accesorios->Funda == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Funda del Dispositivo    '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 120, 8, 4, 'D');
            }
            if($accesorios->Lapiz == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Lapiz                              '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 125, 8, 4, 'D');
            }
            if($accesorios->Powerbank == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Powerbank                     '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 130, 8, 4, 'D');
            }

        }else if($respuesta[0]["tipodispositivo"] == "Laptop"){
            if($accesorios->Maletin == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Maletin                           '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 110, 8, 4, 'D');
            }
            if($accesorios->Cargador == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Cargador                        '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 115, 8, 4, 'D');
            }
            if($accesorios->Mouse == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Mouse                            '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 120, 8, 4, 'D');
            }
            if($accesorios->Mousepad == "1"){
                $pdf->Cell(0,5,mb_convert_encoding(' *  Mousepad                      '.'X', 'ISO-8859-1', 'UTF-8'),0,1);
                $pdf->Rect(73, 125, 8, 4, 'D');
            }

        }else{

        }

        $pdf->Ln(5);
        $pdf->SetFont('Arial','',10);
        $pdf->MultiCell(0, 5, mb_convert_encoding('Haciendo constar que la presente asignación es para uso exclusivo de las funciones encomendadas como consultor en el Programa de Modernización del Sistema Estadístico de El Salvador, no pudiendo dar un uso diferente ni permitir su uso a persona distinta, además tiene la obligación de conservarlo en buenas condiciones y devolverlo al finalizar la consultoría o al momento que le sea requerido.', 'ISO-8859-1', 'UTF-8'), 0, 1);
        $pdf->Ln(5);
        $pdf->SetFont('Arial','',11);
        $pdf->Cell(0,20,'Entrega:',0,0,'L',0);
        $pdf->Cell(0,20,'Recibe:                                       ',0,0,'R',0);
        $pdf->Ln();
        $pdf->Cell(0,10,'F:________________________',0,0,'L',0);
        $pdf->Cell(0,10,'F:________________________',0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('Arial','',11);
        $pdf->Cell(0,5,mb_convert_encoding('Nombre: '.$responsable["nombreconsultor"], 'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Nombre: '.$_SESSION["nombre"], 'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln();
        $pdf->Cell(0,5,mb_convert_encoding('Cargo: '.$responsable["cargoconsultor"], 'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Cargo: Técnico de Soporte Informático', 'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('Arial','B',11);
        $pdf->Cell(0,5,mb_convert_encoding(' Banco Central de Reserva de El Salvador', 'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Consultor                   ', 'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln(20);
        $pdf->SetFont('Arial','U',11);
        $pdf->Cell(0,5,mb_convert_encoding('San Miguel, 27 de noviembre 2023', 'ISO-8859-1', 'UTF-8'),0,1,'R');
        $pdf->SetFont('Arial','',8);
        $pdf->Cell(0,5,mb_convert_encoding('Lugar                             Fecha                   ', 'ISO-8859-1', 'UTF-8'),0,1,'R');

        $pdf->Ln(5);
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(0,5,mb_convert_encoding('Nota: - Cualquier perdida/robo/extravío notificarlo a su jefe inmediato.', 'ISO-8859-1', 'UTF-8'),0,1); 
        $pdf->Cell(0,5,mb_convert_encoding('          - Será responsable de llevar cargado al 100% el equipo al inicio de la jornada.', 'ISO-8859-1', 'UTF-8'),0,1); 


        // Generar el PDF y enviarlo al navegador
        $pdfContent = $pdf->Output('', 'S'); // Captura el contenido en una variable

        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="mi_documento.pdf"');
        header('Content-Length: ' . strlen($pdfContent));

        echo $pdfContent;
        exit;

    } catch(Exception $e){
        header("HTTP/1.1 500 Internal Server Error");
        echo "Error al generar el PDF: " . $e->getMessage();
    }
}
?>