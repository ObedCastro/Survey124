<?php

session_start();

include('fechaes.php');

require "../modelos/conexion.php";
require_once "../controladores/dispositivos.controlador.php";
require_once "../controladores/consultores.controlador.php";
require_once "../controladores/sedes.controlador.php";
require_once "../modelos/dispositivos.modelo.php";
require_once "../modelos/consultores.modelo.php";
require_once "../modelos/sedes.modelo.php";

require('fpdf.php');

class PDF extends FPDF{

   //Pie de página
   function Footer()
   {
    //Posición: a 1,5 cm del final
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Número de página
    $this->Cell(0,10,'Documento Confidencial - Pagina'.$this->PageNo().'/{nb}',0,0,'C');
   }

}

date_default_timezone_set('America/El_Salvador');

if(isset($_GET["idDispositivoRecuperar"]) && isset($_GET["responsableActual"])){

    $item = "iddispositivo";
    $valor = $_GET["idDispositivoRecuperar"];
    $resActual = $_GET["responsableActual"];
    $comentario = $_GET["comentarioRecuperar"];

    if($_GET["condicionDispositivo"] == "option1"){
        $estado = "1";
    } else if($_GET["condicionDispositivo"] == "option2"){
        $estado = "3";
    } else if($_GET["condicionDispositivo"] == "option3"){
        $estado = "4";
    }

    $datos = array(
        "Cubo"=>isset($_GET["checkCubo"]) == "on" ? "1" : "0",
        "Cable"=>isset($_GET["checkCable"]) == "on" ? "1" : "0",
        "Funda"=>isset($_GET["checkFunda"]) == "on" ? "1" : "0",
        "Lapiz"=>isset($_GET["checkLapiz"]) == "on" ? "1" : "0",
        "Powerbank"=>isset($_GET["checkPowerbank"]) == "on" ? "1" : "0",
        "Maletin"=>isset($_GET["checkMaletin"]) == "on" ? "1" : "0",
        "Cargador"=>isset($_GET["checkCargador"]) == "on" ? "1" : "0",
        "Mouse"=>isset($_GET["checkMouse"]) == "on" ? "1" : "0",
        "Mousepad"=>isset($_GET["checkMousepad"]) == "on" ? "1" : "0"
    );

    $responsable = ControladorConsultores::ctrMostrarConsultores("idconsultor", $resActual);
    $sede = ControladorSedes::ctrMostrarSedes("idsede", $responsable["sedeconsultor"]);
    
    $accesorios = json_encode($datos);
    $resultado = ControladorDispositivos::ctrMostrarDispositivoRecuperar($item, $valor, $resActual);
    $respuesta = $resultado[0];
    //$respuesta = ControladorDispositivos::ctrAsignarDispositivo($id, $resActual, $accesorios, $comentario);

    ControladorDispositivos::ctrCambiarEstadoDispositivo("iddispositivo", $valor, $accesorios, $estado, $comentario);

    $arreglo = (array) $respuesta;

    try {

        $pdf=new PDF('P','mm',array(216,279));
        $pdf->SetMargins(28, 25, 28);
        $pdf->AliasNbPages();

        //Primera página
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',13);
        $pdf->Image('img/MARCA DE WATER.png',0, 0, 216);
        $pdf->Image('img/logo_BCR.png',85,15,38);
        $pdf->Ln(15);
        $pdf->SetFont('Arial','B',13);
        $pdf->Cell(0,10,mb_convert_encoding('RECEPCIÓN DE DISPOSITIVO MÓVIL', 'ISO-8859-1', 'UTF-8'),0,0,'C');
        $pdf->Ln(15);
        $pdf->SetFont('Arial','',11);
        $pdf->MultiCell(0, 5, mb_convert_encoding('En este acto se hace recepcion de: '.strtoupper($responsable["nombreconsultor"]).', con el cargo de: '.strtoupper($responsable["cargoconsultor"]).' destacado en la sede: '.strtoupper($sede["nombresede"]." ".$sede["departamentosede"]).' el dispositivo que a continuación se describe:','ISO-8859-1', 'UTF-8'), 0, 1);
        $pdf->Ln(8);

        //TABLA CABEX
        $pdf->SetFont('Arial','B',11);

        //Cabecera
        $pdf->setTextColor(255, 255, 255);
        $pdf->SetFillColor(29,80,153);
        $pdf->SetLineWidth(.3);
        $pdf->SetFont('','B');
        $pdf->Cell(30,6,'DESCRIPCION',1,0,'C',1);
        $pdf->Cell(30,6,'MARCA',1,0,'C',1);
        $pdf->Cell(36,6,'MODELO',1,0,'C',1);

        if($arreglo['tipodispositivo'] != 'Laptop'){
            $pdf->Cell(36,6,'IMEI',1,0,'C',1);
        }else{
            $pdf->Cell(36,6,'SERIE',1,0,'C',1);
        }

        $pdf->Cell(25,6,'TELEFONO',1,0,'C',1);
        $pdf->Ln();

        //Datos
        $pdf->SetFillColor(224,235,255);
        $pdf->SetTextColor(0);
        $pdf->SetFont('');

            $pdf->Cell(30,6,$arreglo['tipodispositivo'],'LR',0,'C');
            $pdf->Cell(30,6,$arreglo['marcadispositivo'],'LR',0,'C');
            $pdf->Cell(36,6,$arreglo['modelodispositivo'],'LR',0,'C');

            if($arreglo['tipodispositivo'] != 'Laptop'){
                $pdf->Cell(36,6,$arreglo['imeidispositivo'],'LR',0,'C');
            } else{
                $pdf->Cell(36,6,$arreglo['seriedispositivo'],'LR',0,'C');
            }

            $pdf->Cell(25,6,$arreglo['telefonodispositivo'],'LR',0,'C');
        

        $pdf->Ln();
        $pdf->Cell(157,0,'','T');
        $pdf->Ln(10);
        $pdf->SetFont('Arial','',11);
        $pdf->Cell(0,5,'Con los siguientes accesorios:',0,0,'C');
        $pdf->Ln(10);


        if($arreglo["tipodispositivo"] == "Telefono"){

            $bandera1 = "";
            $bandera2 = "";
            $bandera3 = "";
            $bandera5 = "";

            if($datos["Cubo"] == "1"){ $bandera1 = "X"; }
            if($datos["Cable"] == "1"){ $bandera2 = "X"; }
            if($datos["Funda"] == "1"){ $bandera3 = "X";  }
            if($datos["Powerbank"] == "1"){ $bandera5 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Cubo de carga               '.$bandera1, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 110, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cable USB tipo C          '.$bandera2, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 115, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Funda del Dispositivo    '.$bandera3, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 120, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Powerbank                     '.$bandera5, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 125, 8, 4, 'D');


        } else if($arreglo["tipodispositivo"] == "Tablet"){
            $bandera1 = "";
            $bandera2 = "";
            $bandera3 = "";
            $bandera4 = "";
            $bandera5 = "";

            if($datos["Cubo"] == "1"){ $bandera1 = "X"; }
            if($datos["Cable"] == "1"){ $bandera2 = "X"; }
            if($datos["Funda"] == "1"){ $bandera3 = "X";  }
            if($datos["Lapiz"] == "1"){ $bandera4 = "X"; }
            if($datos["Powerbank"] == "1"){ $bandera5 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Cubo de carga               '.$bandera1, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 110, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cable USB tipo C          '.$bandera2, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 115, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Funda del Dispositivo    '.$bandera3, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 120, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Lapiz                              '.$bandera4, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 125, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Powerbank                     '.$bandera5, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 130, 8, 4, 'D');

        }else if($arreglo["tipodispositivo"] == "Laptop"){
          $bandera6 = "";
          $bandera7 = "";
          $bandera8 = "";
          $bandera9 = "";

            if($datos["Maletin"] == "1"){ $bandera6 = "X"; }
            if($datos["Cargador"] == "1"){ $bandera7 = "X"; }
            if($datos["Mouse"] == "1"){ $bandera8 = "X"; }
            if($datos["Mousepad"] == "1"){ $bandera9 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Maletin                           '.$bandera6, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 110, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cargador                        '.$bandera7, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 115, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Mouse                            '.$bandera8, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 120, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Mousepad                      '.$bandera9, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 125, 8, 4, 'D');

        }else{

        }

        $pdf->Ln(8);
        $pdf->SetFont('Arial','',11);
        $pdf->Cell(0,5,'Comentarios:',0,0,'L');
        $pdf->Ln(10);
        $pdf->MultiCell(0,5,mb_convert_encoding($comentario, 'ISO-8859-1', 'UTF-8'),0,1);
        $pdf->Rect(28, 143, 158, 40, 'D');
        $pdf->Ln(40);
        $pdf->SetFont('Arial','',11);
        $pdf->Cell(0,20,'Entrega:',0,0,'L',0);
        $pdf->Cell(0,20,'Recibe:                                       ',0,0,'R',0);
        $pdf->Ln();
        $pdf->Cell(0,8,'F:________________________',0,0,'L',0);
        $pdf->Cell(0,8,'F:________________________',0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('Arial','',11);
        $pdf->Cell(0,5,mb_convert_encoding('Nombre: '.$responsable["nombreconsultor"],'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Nombre: '.$_SESSION["nombre"],'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln();
        $pdf->Cell(0,5,mb_convert_encoding('Cargo: '.$responsable["cargoconsultor"],'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Cargo: '.$_SESSION["cargo"],'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln(15);
        $pdf->SetFont('Arial','U',11);

        setlocale(LC_TIME, "spanish");

        $fecha = date('Y-m-d');
        $pdf->Cell(0,5,mb_convert_encoding($sede["departamentosede"].', '.fechaEs($fecha), 'ISO-8859-1', 'UTF-8'),0,1,'R');
        $pdf->SetFont('Arial','',8);
        $pdf->Cell(0,5,mb_convert_encoding('Lugar                             Fecha                   ','ISO-8859-1', 'UTF-8'),0,1,'R');
        $pdf->Ln(5);

        $pdf->SetFont('Arial','',10);

        // Generar el PDF y enviarlo al navegador
        $pdfContent = $pdf->Output('', 'S'); // Captura el contenido en una variable

        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="hoja_recepcion.pdf"');
        header('Content-Length: ' . strlen($pdfContent));

        echo $pdfContent;
        exit;
    } catch(Exception $e){
        header("HTTP/1.1 500 Internal Server Error");
        echo "Error al generar el PDF: " . $e->getMessage();
    }
}
?>